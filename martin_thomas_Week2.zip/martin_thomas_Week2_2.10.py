Number1 = int(input("Enter the First Integer: "))

Number2 = int(input("Enter the Second Integer: "))

Number3 = int(input("Enter the Third Integer: "))

Sum = Number1 + Number2 + Number3
Average = Sum / 3
Product = Number1 * Number2 * Number3

Largest = max(Number1, Number2, Number3)
Smallest = min(Number1, Number2, Number3)

print("The Sum of the three numbers is", Sum)
print("The Average of the three numbers is", Average)
print("The Product of the three numbers is", Product)
print("The Largest of the three numbers is", Largest)
print("The Smallest of the three numbers is", Smallest)
