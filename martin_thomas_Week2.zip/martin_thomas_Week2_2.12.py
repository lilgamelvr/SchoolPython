Principal = 1000

Rate = 7

a = Principal * pow((1 + (Rate / 100)), 10)
print('Amount after 10 years:', a)

b = Principal * pow((1 + (Rate / 100)), 20)
print('Amount after 20 years:', b)

c = Principal * pow((1 + (Rate / 100)), 30)
print('Amount after 30 years:', c)
