print('number\tsquare\tcube')
for x in range(0, 6):
    square = x * x
    cube = x * x * x
    print(f'{x}\t\t{square}\t\t{cube}')
