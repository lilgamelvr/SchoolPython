print("The integer value of B is", ord('B'))

print("The integer value of C is", ord('C'))

print("The integer value of D is", ord('D'))

print("The integer value of b is", ord('b'))

print("The integer value of c is", ord('c'))

print("The integer value of d is", ord('d'))

print("The integer value of 0 is", ord('0'))

print("The integer value of 1 is", ord('1'))

print("The integer value of 2 is", ord('2'))

print("The integer value of $ is", ord('$'))

print("The integer value of * is", ord('*'))

print("The integer value of + is", ord('+'))

print("The integer value of a space is", ord(' '))